// This file is required by the index.html file and will
// be executed in the renderer process for that window.
// All of the Node.js APIs are available in this process.

// Vienere encryption and decryption functions
const lowerReference = 'abcdefghijklmnopqrstuvwxyz';
const upperReference = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

function isalpha(str) {
    return (/^[a-zA-Z]+$/).test(str);
}

function process(word, phrase, flag = 1) {
    // check if arguments are correct
    if (typeof word !== 'string' || typeof phrase !== 'string') {
        throw new Error('vignere: key word and phrase must be strings');
    }

    // throw error if word is not valid
    if (!isalpha(word)) {
        console.log("key:" + word)
        throw new Error('vignere: key word can only contain letters');
    }

    // pass key word all to lower case
    word = word.toLowerCase();

    const len = phrase.length;
    const wlen = word.length;

    let i = 0,
        wi = 0,
        ci,
        pos,
        result = '';

    for (; i < len; i++) {
        pos = phrase[i];
        if (isalpha(pos)) {
            if (flag > 0) {
                ci = lowerReference.indexOf(pos.toLowerCase()) + lowerReference.indexOf(word[wi]);
            } else {
                ci = lowerReference.indexOf(pos.toLowerCase()) - lowerReference.indexOf(word[wi]);
                ci = ci < 0 ? 26 + ci : ci;
            }
            ci %= 26;
            // take cipher from lower or upper reference
            result = lowerReference.indexOf(pos) === -1 ? result + upperReference[ci] : result + lowerReference[ci];
            // reset word index when it exceeds word length
            wi = wi + 1 === wlen ? 0 : wi + 1;
        } else {
            result += pos;
        }
    }

    return result;
}

function vigenere(plaintext, key) {
    return process(key, plaintext)
}


function vigenere_decrypt(ciphertext, key) {
    return process(key, ciphertext, -1)
}

function ord(str) {
    return str.charCodeAt(0);
}

// Cipher solver

ENGLISH_FREQ = [0.0749, 0.0129, 0.0354, 0.0362, 0.1400, 0.0218, 0.0174, 0.0422, 0.0665, 0.0027, 0.0047,
    0.0357, 0.0339, 0.0674, 0.0737, 0.0243, 0.0026, 0.0614, 0.0695, 0.0985, 0.0300, 0.0116,
    0.0169, 0.0028, 0.0164, 0.0004]

__english_data = {
    'A': 8.167, 'B': 1.492, 'C': 2.782, 'D': 4.253, 'E': 12.702,
    'F': 2.228, 'G': 2.015, 'H': 6.094, 'I': 6.996, 'J': 0.153,
    'K': 0.772, 'L': 4.025, 'M': 2.406, 'N': 6.749, 'O': 7.507,
    'P': 1.929, 'Q': 0.095, 'R': 5.987, 'S': 6.327, 'T': 9.056,
    'U': 2.758, 'V': 0.978, 'W': 2.360, 'X': 0.150, 'Y': 1.974,
    'Z': 0.074, 'max_val': 12.702, 'kappa': 0.0667
}

__french_data = {
    'A': 8.11, 'B': 0.903, 'C': 3.49, 'D': 4.27, 'E': 17.22,
    'F': 1.14, 'G': 1.09, 'H': 0.769, 'I': 7.44, 'J': 0.339,
    'K': 0.097, 'L': 5.53, 'M': 2.89, 'N': 7.46, 'O': 5.38,
    'P': 3.02, 'Q': 0.999, 'R': 7.05, 'S': 8.04, 'T': 6.99,
    'U': 5.65, 'V': 1.30, 'W': 0.039, 'X': 0.435, 'Y': 0.271,
    'Z': 0.098, 'max_val': 17.22, 'kappa': 0.0746
}

__german_data = {
    'A': 6.506, 'B': 2.566, 'C': 2.837, 'D': 5.414, 'E': 16.693,
    'F': 2.044, 'G': 3.647, 'H': 4.064, 'I': 7.812, 'J': 0.191,
    'K': 1.879, 'L': 2.825, 'M': 3.005, 'N': 9.905, 'O': 2.285,
    'P': 0.944, 'Q': 0.055, 'R': 6.539, 'S': 6.765, 'T': 6.742,
    'U': 3.703, 'V': 1.069, 'W': 1.396, 'X': 0.022, 'Y': 0.032,
    'Z': 1.002, 'max_val': 16.693, 'kappa': 0.0767
}

__italian_data = {
    'A': 11.30, 'B': 0.975, 'C': 4.35, 'D': 3.80, 'E': 11.24,
    'F': 1.09, 'G': 1.73, 'H': 1.02, 'I': 11.57, 'J': 0.035,
    'K': 0.078, 'L': 6.40, 'M': 2.66, 'N': 7.29, 'O': 9.11,
    'P': 2.89, 'Q': 0.391, 'R': 6.68, 'S': 5.11, 'T': 6.76,
    'U': 3.18, 'V': 1.52, 'W': 0.00, 'X': 0.024, 'Y': 0.048,
    'Z': 0.958, 'max_val': 11.57, 'kappa': 0.0733
}

__portuguese_data = {
    'A': 13.89, 'B': 0.980, 'C': 4.18, 'D': 5.24, 'E': 12.72,
    'F': 1.01, 'G': 1.17, 'H': 0.905, 'I': 6.70, 'J': 0.317,
    'K': 0.0174, 'L': 2.76, 'M': 4.54, 'N': 5.37, 'O': 10.90,
    'P': 2.74, 'Q': 1.06, 'R': 6.67, 'S': 7.90, 'T': 4.63,
    'U': 4.05, 'V': 1.55, 'W': 0.0104, 'X': 0.272, 'Y': 0.0165,
    'Z': 0.400, 'max_val': 13.89, 'kappa': 0.0745
}

__spanish_data = {
    'A': 12.09, 'B': 1.21, 'C': 4.20, 'D': 4.65, 'E': 13.89,
    'F': 0.642, 'G': 1.11, 'H': 1.13, 'I': 6.38, 'J': 0.461,
    'K': 0.038, 'L': 5.19, 'M': 2.86, 'N': 7.23, 'O': 9.58,
    'P': 2.74, 'Q': 1.37, 'R': 6.14, 'S': 7.43, 'T': 4.49,
    'U': 4.53, 'V': 1.05, 'W': 0.011, 'X': 0.124, 'Y': 1.14,
    'Z': 0.324, 'max_val': 13.89, 'kappa': 0.0766
}

function compare_freq(text) {
    if (text.length == 0) {
        return null
    }
    text = text.toLowerCase()
    mapText = "";
    for (var i = 0; i < text.length; i++) {
        t = text[i];
        if (lowerReference.indexOf(t) > -1) {
            mapText += t;
        }
    }
    text = mapText;
    freq = new Array(26)
    freq.fill(0);
    total = text.length
    for (var i = 0; i < text.length; i++) {
        l = text[i];
        freq[ord(l) - ord('a')] += 1
    }

    var sum = 0;
    for (var i = 0; i < freq.length; i++) {
        sum += Math.abs(freq[i] / total - ENGLISH_FREQ[i])
    }

    return sum;
}


function solve_vigenere(text, key_min_size = 1, key_max_size = 30) {
    best_keys = []

    mapText = "";
    text = text.toLowerCase()
    for (var i = 0; i < text.length; i++) {
        t = text[i];
        if (lowerReference.indexOf(t) > -1) {
            mapText += t;
        }
    }
    text_letters = mapText;

    for (var key_length = key_min_size; key_length < key_max_size; key_length++) {
        // Try all possible key lengths
        key = new Array(key_length)
        for (var key_index = 0; key_index < key_length; key_index++) {
            letters = ""
            for (var i = key_index; i < text_letters.length; i += key_length) {
                letters += text_letters[i];
            }
            cur_freq = 1e6
            cur_char = 'a'
            for (var i = 0; i < 26; i++) {
                key_char = lowerReference[i];
                freq = compare_freq(vigenere_decrypt(letters, key_char))
                if (freq < cur_freq) {
                    cur_freq = freq;
                    cur_char = key_char;
                }
            }
            key[key_index] = cur_char;
        }
        console.log(key);
        best_keys.push(key.join(""))
    }
    best_keys.sort((a, b) => compare_freq(vigenere_decrypt(text, a)) - compare_freq(vigenere_decrypt(text, b)));
    return best_keys;
}

// CIPHERTEXT = "Vvr Ifnvaus Bdwokv Gbtrzsa Vkqgofntja rrlznxk eflvkozjcdue rs “mzg oez ff pjkhvtx ok kqzioeg vgfsf.” Zyil au vvykokaeoyrp avuwfnzv, bnl fcry eom ucdgaie mzg qhxiegl dfrguta gh huk wixdf ce oks ijggrtk-dtq uqvketbxkq sulnwsvwbtj. Taw fssoeimaqb sutulwu gbrvlr gp huk towwu hugk htng prke ulwf tbx teglwfvkj th wpoorv sxutsg ifmfmpwpgkihf. Dig iiyilquegghr fqknjryl wpqbsgalkgg zath fgts gnrn mzkg: vz uetdu kvzy mxujoaojml xqf rtjukapu vtkezjkhl, zvcafkehkj fhj glpnrnzapu fktrxl msly, grhlqqbrj fhj cignvnmaeogoeg nkgff, kcevltcaot anuvwbtj agv gzrikihfu, rvmzttd eofn, rnw eqfr. Cztagwh nzkefhvwam ko ijqjvjv a vgodykke vzcfnikekabogofn, pw ychru stq vvnz dowwtb pxppmgifnvyy bfxcybvs mzg ggauy hx oognvmtlkqnr kevzpwdavs ygt grilrbfi rvmzttd kbsuimtlkca, ypsmwog, ntu dbkvfvhltxv eczvlttlkcay rgtapgg guvxjuoeorl tlvopqj. fesi{3osir4d633096u273734wct73r6985l4wc2us213}"

function crack(CIPHERTEXT) {
    for (var key of solve_vigenere(CIPHERTEXT)) {

        return [key, vigenere_decrypt(CIPHERTEXT, key)];
    }
}


///////////
//base64
///////////

let alphabet64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function fill(char) {
    var bitstr = char.charCodeAt(0).toString(2);
    while (bitstr.length < 8) bitstr = '0' + bitstr;
    return bitstr;
}

//console.log(parseInt(fill(' '), 2));

function base64encode(input) {
    var _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var output = "";
    var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
    var i = 0;
    while (i < input.length) {
        chr1 = input.charCodeAt(i++);
        chr2 = input.charCodeAt(i++);
        chr3 = input.charCodeAt(i++);
        enc1 = chr1 >> 2;
        enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
        enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
        enc4 = chr3 & 63;
        if (isNaN(chr2)) {
            enc3 = enc4 = 64;
        } else if (isNaN(chr3)) {
            enc4 = 64;
        }
        output = output + _keyStr.charAt(enc1) + _keyStr.charAt(enc2)
            + _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
    }
    return output;
};

function base64decode(input) {
    var _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var output = "";
    var chr1, chr2, chr3;
    var enc1, enc2, enc3, enc4;
    var i = 0;

    while (i < input.length) {
        enc1 = _keyStr.indexOf(input.charAt(i++));
        enc2 = _keyStr.indexOf(input.charAt(i++));
        enc3 = _keyStr.indexOf(input.charAt(i++));
        enc4 = _keyStr.indexOf(input.charAt(i++));
        chr1 = (enc1 << 2) | (enc2 >> 4);
        chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
        chr3 = ((enc3 & 3) << 6) | enc4;
        output = output + String.fromCharCode(chr1);
        if (enc3 != 64) {
            output = output + String.fromCharCode(chr2);
        }
        if (enc4 != 64) {
            output = output + String.fromCharCode(chr3);
        }
    }

    return output;
};

module.exports = {
    crack: crack,
    vigenere_decrypt: vigenere_decrypt,
    vigenere: vigenere,
    base64decode: base64decode,
    base64encode: base64encode,
};
  
    